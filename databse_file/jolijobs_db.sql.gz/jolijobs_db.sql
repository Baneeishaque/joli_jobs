-- MySQL dump 10.17  Distrib 10.3.23-MariaDB, for Linux (x86_64)
--
-- Host: localhost    Database: jolijobs_db
-- ------------------------------------------------------
-- Server version	10.3.23-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `admin`
--

DROP TABLE IF EXISTS `admin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `admin` (
  `id` int(255) NOT NULL AUTO_INCREMENT,
  `admin_name` varchar(20) NOT NULL,
  `admin_pass` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `admin`
--

LOCK TABLES `admin` WRITE;
/*!40000 ALTER TABLE `admin` DISABLE KEYS */;
INSERT INTO `admin` (`id`, `admin_name`, `admin_pass`) VALUES (1,'admin','32250170a0dca92d53ec9624f336ca24');
/*!40000 ALTER TABLE `admin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `applications`
--

DROP TABLE IF EXISTS `applications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `applications` (
  `id` int(255) NOT NULL AUTO_INCREMENT,
  `user_id` varchar(255) NOT NULL,
  `vacancy_id` varchar(255) NOT NULL,
  `date` date NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `applications`
--

LOCK TABLES `applications` WRITE;
/*!40000 ALTER TABLE `applications` DISABLE KEYS */;
INSERT INTO `applications` (`id`, `user_id`, `vacancy_id`, `date`) VALUES (1,'2','3','2020-04-01'),(2,'3','3','2020-04-01'),(3,'4','3','2020-04-01'),(4,'5','3','2020-04-01'),(5,'6','4','2020-04-01'),(6,'7','4','2020-04-01'),(7,'','10','2020-05-26');
/*!40000 ALTER TABLE `applications` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `categories`
--

DROP TABLE IF EXISTS `categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `categories` (
  `id` int(255) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `categories`
--

LOCK TABLES `categories` WRITE;
/*!40000 ALTER TABLE `categories` DISABLE KEYS */;
INSERT INTO `categories` (`id`, `name`) VALUES (1,'category 1'),(2,'category 2'),(3,'category 3'),(4,'category 4'),(5,'category 5'),(6,'category 6'),(7,'category 7'),(9,'category 9'),(10,'category 10');
/*!40000 ALTER TABLE `categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` int(50) NOT NULL AUTO_INCREMENT,
  `first_name` varchar(50) NOT NULL,
  `last_name` varchar(50) NOT NULL,
  `dob` varchar(20) NOT NULL,
  `resume` varchar(100) NOT NULL,
  `email` varchar(50) DEFAULT NULL,
  `phone` varchar(15) NOT NULL,
  `gender` varchar(1) NOT NULL,
  `present_address` varchar(500) NOT NULL,
  `permanent_address` varchar(500) DEFAULT NULL,
  `educational_qualification` varchar(30) DEFAULT NULL,
  `age` varchar(2) DEFAULT NULL,
  `payment` varchar(7) DEFAULT NULL,
  `password` varchar(60) NOT NULL DEFAULT 'pass123',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` (`id`, `first_name`, `last_name`, `dob`, `resume`, `email`, `phone`, `gender`, `present_address`, `permanent_address`, `educational_qualification`, `age`, `payment`, `password`) VALUES (1,'abu','thahir','22-06-1997','file1.pdf','msabuthahirk@gmail.com','9061827202','m','kelamthodi house','kelamthodi house','bachelors in technology','23','5000','32250170a0dca92d53ec9624f336ca24'),(2,'abu','thahir','22-06-1997','file1.pdf','msabuthahirk@gmail.com','9061827202','m','kelamthodi house','kelamthodi house','bachelors in technology','23','5000','32250170a0dca92d53ec9624f336ca24'),(3,'abu','thahir','22-06-1997','file1.pdf','msabuthahirk@gmail.coma','9061827202','m','kelamthodi house','kelamthodi house','bachelors in technology','23','5000','32250170a0dca92d53ec9624f336ca24'),(4,'abu','thahir','22-06-1997','file1.pdf','msabuthahirk@gmail.com','9061827202','m','kelamthodi house','kelamthodi house','bachelors in technology','23','5000','32250170a0dca92d53ec9624f336ca24'),(5,'abu','thahir','22-06-1997','file1.pdf','msabuthahirk@gmail.com','9061827202','m','kelamthodi house','kelamthodi house','bachelors in technology','23','5000','32250170a0dca92d53ec9624f336ca24'),(6,'abu','thahir','22-06-1997','file1.pdf','msabuthahirk@gmail.com','9061827202','m','kelamthodi house','kelamthodi house','bachelors in technology','23','5000','32250170a0dca92d53ec9624f336ca24'),(7,'abu','thahir','22-06-1997','file1.pdf','msabuthahirk@gmail.com','9061827202','m','kelamthodi house','kelamthodi house','bachelors in technology','23','5000','32250170a0dca92d53ec9624f336ca24'),(8,'abu','thahir','22-06-1997','file1.pdf','msabuthahirk@gmail.com','9061827202','m','kelamthodi house','kelamthodi house','bachelors in technology','23','5000','32250170a0dca92d53ec9624f336ca24'),(9,'abu','thahir','22-06-1997','file1.pdf','msabuthahirk@gmail.com','9061827202','m','kelamthodi house','kelamthodi house','bachelors in technology','23','5000','32250170a0dca92d53ec9624f336ca24'),(10,'abu','thahir','22-06-1997','file1.pdf','msabuthahirk@gmail.com','9061827202','m','kelamthodi house','kelamthodi house','bachelors in technology','23','5000','32250170a0dca92d53ec9624f336ca24');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `vacancies`
--

DROP TABLE IF EXISTS `vacancies`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `vacancies` (
  `id` int(255) NOT NULL AUTO_INCREMENT,
  `job_title` varchar(30) NOT NULL,
  `job_role` varchar(30) NOT NULL,
  `employer_name` varchar(50) NOT NULL,
  `job_description` varchar(500) NOT NULL,
  `contact_number` varchar(15) NOT NULL,
  `date_post` date NOT NULL,
  `whatsapp_number` varchar(15) NOT NULL,
  `category` varchar(50) NOT NULL,
  `place` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `vacancies`
--

LOCK TABLES `vacancies` WRITE;
/*!40000 ALTER TABLE `vacancies` DISABLE KEYS */;
INSERT INTO `vacancies` (`id`, `job_title`, `job_role`, `employer_name`, `job_description`, `contact_number`, `date_post`, `whatsapp_number`, `category`, `place`) VALUES (1,'engineer','project manager','microsoft','lorem ipsum','919061827202','2020-04-06','+919061827202','category3','abc'),(2,'engineer','project manager','microsoft','lorem ipsum','919061827202','2020-04-06','+919061827202','category3','asd'),(3,'engineer','project manager','microsoft','lorem ipsum','919061827202','2020-04-06','+919061827202','category3','qwe'),(4,'engineer','project manager','microsoft','lorem ipsum','919061827202','2020-04-06','+919061827202','category3','wer'),(5,'engineer','project manager','microsoft','lorem ipsum','919061827202','2020-04-06','+919061827202','category3','rty'),(6,'engineer','project manager','microsoft','lorem ipsum','919061827202','2020-04-06','+919061827202','category3','tyu'),(7,'engineer','project manager','microsoft','lorem ipsum','919061827202','2020-04-06','+919061827202','category3','wer'),(8,'engineer','project manager','microsoft','lorem ipsum','919061827202','2020-04-06','+919061827202','category3','fghfg.'),(9,'engineer','project manager','microsoft','lorem ipsum','919061827202','2020-04-06','+919061827202','category3','dfgdfg'),(10,'engineer','project manager','microsoft','lorem ipsum','919061827202','2020-04-06','+919061827202','category3','ghjgh');
/*!40000 ALTER TABLE `vacancies` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'jolijobs_db'
--

--
-- Dumping routines for database 'jolijobs_db'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-26 21:15:48
