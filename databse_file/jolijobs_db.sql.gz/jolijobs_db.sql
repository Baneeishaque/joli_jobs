-- MySQL dump 10.17  Distrib 10.3.23-MariaDB, for Linux (x86_64)
--
-- Host: localhost    Database: jolijobs_db
-- ------------------------------------------------------
-- Server version	10.3.23-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `admin`
--

DROP TABLE IF EXISTS `admin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `admin` (
  `id` int(255) NOT NULL AUTO_INCREMENT,
  `admin_name` varchar(20) NOT NULL,
  `admin_pass` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `admin`
--

LOCK TABLES `admin` WRITE;
/*!40000 ALTER TABLE `admin` DISABLE KEYS */;
INSERT INTO `admin` (`id`, `admin_name`, `admin_pass`) VALUES (1,'admin','32250170a0dca92d53ec9624f336ca24');
/*!40000 ALTER TABLE `admin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `applications`
--

DROP TABLE IF EXISTS `applications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `applications` (
  `id` int(255) NOT NULL AUTO_INCREMENT,
  `user_id` varchar(255) NOT NULL,
  `vacancy_id` varchar(255) NOT NULL,
  `date` date NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=22 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `applications`
--

LOCK TABLES `applications` WRITE;
/*!40000 ALTER TABLE `applications` DISABLE KEYS */;
INSERT INTO `applications` (`id`, `user_id`, `vacancy_id`, `date`) VALUES (5,'6','4','2020-04-01'),(6,'1','4','2020-04-01'),(7,'1','5','2020-04-01'),(8,'1','11','2020-04-20'),(10,'1','12','2020-04-20'),(11,'1','6','2020-04-20'),(12,'1','10','2020-04-21'),(13,'1','7','2020-04-23'),(15,'12','13','2020-04-24'),(16,'','12','2020-04-26'),(17,'','12','2020-04-26'),(18,'','17','2020-04-29'),(19,'','17','2020-05-04'),(20,'','7','2020-05-13'),(21,'','17','2020-05-19');
/*!40000 ALTER TABLE `applications` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `categories`
--

DROP TABLE IF EXISTS `categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `categories` (
  `id` int(255) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `categories`
--

LOCK TABLES `categories` WRITE;
/*!40000 ALTER TABLE `categories` DISABLE KEYS */;
INSERT INTO `categories` (`id`, `name`) VALUES (1,'category 1'),(2,'category 2'),(3,'category 3'),(4,'category 4'),(5,'category 5'),(6,'category 6'),(7,'category 7');
/*!40000 ALTER TABLE `categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` int(50) NOT NULL AUTO_INCREMENT,
  `first_name` varchar(50) NOT NULL,
  `last_name` varchar(50) DEFAULT NULL,
  `dob` varchar(20) NOT NULL,
  `resume` varchar(100) NOT NULL,
  `email` varchar(50) DEFAULT NULL,
  `phone` varchar(15) NOT NULL,
  `gender` varchar(1) NOT NULL,
  `present_address` varchar(500) NOT NULL,
  `permanent_address` varchar(500) DEFAULT NULL,
  `educational_qualification` varchar(30) DEFAULT NULL,
  `age` varchar(2) DEFAULT NULL,
  `payment` varchar(7) DEFAULT NULL,
  `password` varchar(60) NOT NULL,
  `txn` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=19 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` (`id`, `first_name`, `last_name`, `dob`, `resume`, `email`, `phone`, `gender`, `present_address`, `permanent_address`, `educational_qualification`, `age`, `payment`, `password`, `txn`) VALUES (1,'abu','thahir','22-06-1997','file1.pdf','msabuthahirk@gmail.com','9061827202','m','kelamthodi house','kelamthodi house','bachelors in technology','23','5000','pass123',NULL),(2,'abu','thahir','22-06-1997','file1.pdf','msabuthahirk@gmail.com','9061827202','m','kelamthodi house','kelamthodi house','bachelors in technology','23','5000','pass123',NULL),(3,'abu','thahir','22-06-1997','file1.pdf','msabuthahirk@gmail.coma','9061827202','m','kelamthodi house','kelamthodi house','bachelors in technology','23','5000','pass123',NULL),(4,'abu','thahir','22-06-1997','file1.pdf','msabuthahirk@gmail.com','9061827202','m','kelamthodi house','kelamthodi house','bachelors in technology','23','5000','pass123',NULL),(5,'abu','thahir','22-06-1997','file1.pdf','msabuthahirk@gmail.com','9061827202','m','kelamthodi house','kelamthodi house','bachelors in technology','23','5000','pass123',NULL),(6,'abu','thahir','22-06-1997','file1.pdf','msabuthahirk@gmail.com','9061827202','m','kelamthodi house','kelamthodi house','bachelors in technology','23','5000','pass123',NULL),(7,'abu','thahir','22-06-1997','file1.pdf','msabuthahirk@gmail.com','9061827202','m','kelamthodi house','kelamthodi house','bachelors in technology','23','5000','pass123',NULL),(8,'abu','thahir','22-06-1997','file1.pdf','msabuthahirk@gmail.com','9061827202','m','kelamthodi house','kelamthodi house','bachelors in technology','23','5000','pass123',NULL),(9,'abu','thahir','22-06-1997','file1.pdf','msabuthahirk@gmail.com','9061827202','m','kelamthodi house','kelamthodi house','bachelors in technology','23','5000','pass123',NULL),(10,'abu','thahir','22-06-1997','file1.pdf','msabuthahirk@gmail.com','9061827202','m','kelamthodi house','kelamthodi house','bachelors in technology','23','5000','pass123',NULL),(11,'asdasd','asdasd','asda','asda','asd','asd','a','asd','asd','asd','24','250','asdas','asd'),(12,'Abuthahir K','','22-02-1996','uploads/9562085538.png','abuthahir8520@gmail.com','9562085538','m','Kelamthodi, Kulukkallur, Palakkad','Kelamthodi, Kulukkallur, Palakkad','B.Tech CSE','24','520','b4af804009cb036a4ccdc33431ef9ac9','pay_EiOYUgMysvzIE8'),(13,'asdadas','','22-06-2020','uploads/741852963.','test@test','741852963','m','asdasdasd','asdasdasd','asdasd','36','800','e10adc3949ba59abbe56e057f20f883e','pay_EiOwq6gEW8Yl6P'),(14,'Banee Ishaque K','','28/09/1993','uploads/+919446827218.','baneeishaque@gmail.com','+919446827218','m','Kuttiyathil House, Tanalur - 676307','Kuttiyathil House, Tanalur - 676307','B Tech in CS','27','500','efc2b1d08c9ed938c8c750960c41c521','pay_EkhkxHAeTTpdWt'),(16,'divya','','10-10-1974','uploads/09746573656.','skservicespltd007@gmail.com','09746573656','m','gdhhdjjjddm','gdhhdjjjddm','bsc','46','30','933f0172c0445968d5b76c508a2d9879','pay_EqXukBi2jzQnmL'),(17,'Qwrt','','15/01/1994','uploads/9878764554.','saqqd@gmail.com','9878764554','m','Ggyh','Ggyh','Dftghjj','26','1','d8578edf8458ce06fbc5bb76a58c5ca4','pay_Er09CUH8BsFxlT'),(18,'sam','','21-5-1999','uploads/9746573656.','sam@gmail.com','9746573656','m','dfajdkmkm','dfajdkmkm','bba','21','1','56fafa8964024efa410773781a5f9e93','pay_Es7s93wWzgKDzZ');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `vacancies`
--

DROP TABLE IF EXISTS `vacancies`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `vacancies` (
  `id` int(255) NOT NULL AUTO_INCREMENT,
  `job_title` varchar(30) NOT NULL,
  `job_role` varchar(30) NOT NULL,
  `employer_name` varchar(50) NOT NULL,
  `job_description` varchar(500) NOT NULL,
  `contact_number` varchar(15) NOT NULL,
  `date_post` date NOT NULL,
  `whatsapp_number` varchar(15) NOT NULL,
  `category` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=19 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `vacancies`
--

LOCK TABLES `vacancies` WRITE;
/*!40000 ALTER TABLE `vacancies` DISABLE KEYS */;
INSERT INTO `vacancies` (`id`, `job_title`, `job_role`, `employer_name`, `job_description`, `contact_number`, `date_post`, `whatsapp_number`, `category`) VALUES (4,'engineer','project manager','microsoft','lorem ipsum','919061827202','2020-04-06','+919061827202','6'),(5,'engineer','project manager','microsoft','lorem ipsum','919061827202','2020-04-06','+919061827202','6'),(6,'engineer','project manager','microsoft','lorem ipsum','919061827202','2020-04-06','+919061827202','6'),(7,'engineer','project manager','microsoft','lorem ipsum','919061827202','2020-04-06','+919061827202','6'),(8,'engineer','project manager','microsoft','lorem ipsum','919061827202','2020-04-06','+919061827202','6'),(9,'engineer','project manager','microsoft','lorem ipsum','919061827202','2020-04-06','+919061827202','6'),(10,'engineer','project manager','microsoft','lorem ipsum','919061827202','2020-04-06','+919061827202','6'),(11,'sdfs','sdfs','sdf','sdf','sdf','2020-04-10','sdfsdf','6'),(12,'tested','job rolesad','abuasd','new job asdasd','9061827202','2020-04-15','9061827202','5'),(13,'asdas','ghs','hsgdf','fhsgdf','ghsdf','2020-04-15','sghdf`','6'),(14,'chh','jhjgj','mvhjk','hkj,','knkjlk','2020-04-26','kljkljljo;','1'),(15,'chh','jhjgj','mvhjk','hkj,','knkjlk','2020-04-26','kljkljljo;','1'),(16,'sogff','huhhwke','bhabax','wdewf','1223344545','2020-04-26','1234566788','6'),(17,'sales man','on shop sales','my g','young and smart','04842364534','2020-04-29','333','1'),(18,'receptionsit','front office','asset homes','young and smart','04842364534','2020-05-19','9544773656','1');
/*!40000 ALTER TABLE `vacancies` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'jolijobs_db'
--

--
-- Dumping routines for database 'jolijobs_db'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-24 19:18:43
